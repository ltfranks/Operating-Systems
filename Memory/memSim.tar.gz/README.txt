LUKE FRANKS

everything works as intended.

./memSim fifo1.txt
./memSim fifo1.txt 5
./memSim fifo1.txt 5 opt

are all examples of executables that should work
